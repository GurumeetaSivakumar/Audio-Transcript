import google.generativeai as genai
import json
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

def analyze_sentiment(text: str) -> dict:
    """
    Analyze sentiment of text using Google Gemini API.
    
    Args:
        text: The transcript text to analyze
        
    Returns:
        Dictionary with 'sentiment' and 'confidence' keys
    """
    try:
        # Get API key from environment variable
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise Exception("GEMINI_API_KEY environment variable not set")
        
        print(f"tk -- Initializing Gemini client")
        genai.configure(api_key=api_key)
        
        # Create model instance
        model = genai.GenerativeModel('gemini-2.5-flash')
        # gemini-2.5-flash
        # Create prompt
        prompt = f"""You are a sentiment analysis model. 
Analyze the following text and classify as Positive, Negative, or Neutral. 
Also provide a confidence score between 0 and 1.
Return JSON only in this exact structure:
{{
  "sentiment": "",
  "confidence": 0.0
}}

Text: {text}"""
        
        print(f"tk -- Sending text to Gemini for sentiment analysis. Text length: {len(text)}")
        response = model.generate_content(prompt)
        
        # Extract JSON from response
        response_text = response.text.strip()
        print(f"tk -- Received response from Gemini: {response_text}")
        
        # Try to parse JSON (handle markdown code blocks if present)
        if "```json" in response_text:
            response_text = response_text.split("```json")[1].split("```")[0].strip()
        elif "```" in response_text:
            response_text = response_text.split("```")[1].split("```")[0].strip()
        
        result = json.loads(response_text)
        
        # Validate structure
        if "sentiment" not in result or "confidence" not in result:
            raise Exception("Invalid response structure from Gemini")
        
        print(f"tk -- Sentiment analysis completed. Sentiment: {result['sentiment']}, Confidence: {result['confidence']}")
        return {
            "sentiment": result["sentiment"],
            "confidence": float(result["confidence"])
        }
        
    except json.JSONDecodeError as e:
        print(f"tk -- JSON decode error: {str(e)}")
        raise Exception(f"sentiment_error: Failed to parse Gemini response: {str(e)}")
    except Exception as e:
        print(f"tk -- Sentiment analysis error: {str(e)}")
        raise Exception(f"sentiment_error: {str(e)}")

