from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
import tempfile
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from .whisper_service import transcribe_audio
from .gemini_service import analyze_sentiment

app = FastAPI(title="Audio Transcript & Sentiment Analysis API")

@app.post("/process-audio")
async def process_audio(file: UploadFile = File(...)):
    """
    Process uploaded audio file:
    1. Save file temporarily
    2. Transcribe using Whisper
    3. Analyze sentiment using Gemini
    4. Return combined result
    """
    temp_file_path = None
    
    try:
        print(f"tk -- Received audio file upload: {file.filename}, content_type: {file.content_type}")
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(file.filename)[1]) as temp_file:
            temp_file_path = temp_file.name
            
            # Write uploaded file to temp file
            content = await file.read()
            temp_file.write(content)
            print(f"tk -- Saved temporary file: {temp_file_path}, size: {len(content)} bytes")
        
        # Transcribe audio
        try:
            transcript = transcribe_audio(temp_file_path)
            print(f"tk -- Transcript generated successfully")
        except Exception as e:
            print(f"tk -- Transcription failed: {str(e)}")
            return JSONResponse(
                status_code=200,
                content={
                    "transcript": "",
                    "sentiment": "",
                    "confidence": 0.0,
                    "error": "transcription_error"
                }
            )
        
        # Analyze sentiment
        try:
            sentiment_result = analyze_sentiment(transcript)
            print(f"tk -- Sentiment analysis completed successfully")
        except Exception as e:
            print(f"tk -- Sentiment analysis failed: {str(e)}")
            return JSONResponse(
                status_code=200,
                content={
                    "transcript": transcript,
                    "sentiment": "",
                    "confidence": 0.0,
                    "error": "sentiment_error"
                }
            )
        
        # Return combined result
        result = {
            "transcript": transcript,
            "sentiment": sentiment_result["sentiment"],
            "confidence": sentiment_result["confidence"]
        }
        print(f"tk -- Request processed successfully")
        return JSONResponse(content=result)
        
    except Exception as e:
        print(f"tk -- Unexpected error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
    
    finally:
        # Clean up temporary file
        if temp_file_path and os.path.exists(temp_file_path):
            try:
                os.unlink(temp_file_path)
                print(f"tk -- Cleaned up temporary file: {temp_file_path}")
            except Exception as e:
                print(f"tk -- Failed to delete temp file: {str(e)}")

@app.get("/")
async def root():
    return {"message": "Audio Transcript & Sentiment Analysis API", "endpoint": "/process-audio"}

@app.get("/health")
async def health():
    return {"status": "healthy"}

