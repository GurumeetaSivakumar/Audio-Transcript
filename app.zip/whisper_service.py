import requests
import time
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# AssemblyAI API endpoints
ASSEMBLYAI_API_KEY = os.getenv("ASSEMBLYAI_API_KEY")
UPLOAD_URL = "https://api.assemblyai.com/v2/upload"
TRANSCRIPT_URL = "https://api.assemblyai.com/v2/transcript"

def transcribe_audio(path: str) -> str:
    """
    Transcribe audio file using AssemblyAI API.
    
    Args:
        path: Path to the audio file
        
    Returns:
        Cleaned transcript text
    """
    try:
        print(f"tk -- Starting transcription for file: {path}")
        
        if not ASSEMBLYAI_API_KEY:
            raise Exception(
                "ASSEMBLYAI_API_KEY environment variable not set. "
                "Please get your API key from https://www.assemblyai.com/"
            )
        
        # Step 1: Upload file to AssemblyAI
        print("tk -- Uploading file to AssemblyAI...")
        with open(path, "rb") as audio_file:
            # Use files parameter with filename - requests will set content-type automatically
            upload_response = requests.post(
                UPLOAD_URL,
                headers={"authorization": ASSEMBLYAI_API_KEY},
                files={"file": (os.path.basename(path), audio_file)},
                timeout=300  # 5 minutes timeout for large files
            )
        
        if upload_response.status_code != 200:
            error_msg = upload_response.text
            print(f"tk -- Upload failed: {upload_response.status_code} - {error_msg}")
            raise Exception(f"Upload failed: {upload_response.status_code} - {error_msg}")
        
        upload_data = upload_response.json()
        upload_url = upload_data.get("upload_url")
        
        if not upload_url:
            print(f"tk -- Upload response: {upload_data}")
            raise Exception("Upload succeeded but no upload_url in response")
        
        print(f"tk -- File uploaded successfully, URL: {upload_url}")
        
        # Validate upload_url format
        if not upload_url.startswith("https://"):
            raise Exception(f"Invalid upload_url format: {upload_url}")
        
        # Step 2: Start transcription job
        print("tk -- Starting transcription job...")
        transcript_payload = {
            "audio_url": upload_url
        }
        
        print(f"tk -- Sending transcript request with payload: {transcript_payload}")
        
        transcript_response = requests.post(
            TRANSCRIPT_URL,
            headers={
                "authorization": ASSEMBLYAI_API_KEY,
                "content-type": "application/json"
            },
            json=transcript_payload,
            timeout=30
        )
        
        if transcript_response.status_code != 200:
            error_msg = transcript_response.text
            print(f"tk -- Transcription request failed: {transcript_response.status_code} - {error_msg}")
            print(f"tk -- Request URL: {TRANSCRIPT_URL}")
            print(f"tk -- Request payload: {transcript_payload}")
            raise Exception(f"Transcription request failed: {transcript_response.status_code} - {error_msg}")
        
        transcript_id = transcript_response.json()["id"]
        print(f"tk -- Transcription job started: {transcript_id}")
        
        # Step 3: Poll for completion
        max_attempts = 300  # Maximum 10 minutes (300 * 2 seconds)
        attempt = 0
        
        while attempt < max_attempts:
            status_response = requests.get(
                f"{TRANSCRIPT_URL}/{transcript_id}",
                headers={"authorization": ASSEMBLYAI_API_KEY},
                timeout=30
            )
            
            if status_response.status_code != 200:
                error_msg = status_response.text
                print(f"tk -- Status check failed: {status_response.status_code} - {error_msg}")
                raise Exception(f"Status check failed: {status_response.status_code} - {error_msg}")
            
            status_data = status_response.json()
            status = status_data["status"]
            
            if status == "completed":
                transcript = status_data["text"].strip()
                if not transcript:
                    raise Exception("Transcription completed but no text was returned")
                print(f"tk -- Transcription completed. Length: {len(transcript)} characters")
                return transcript
            elif status == "error":
                error_msg = status_data.get("error", "Unknown error")
                print(f"tk -- Transcription failed: {error_msg}")
                raise Exception(f"Transcription failed: {error_msg}")
            
            # Status is "queued" or "processing", wait and retry
            attempt += 1
            if attempt % 10 == 0:  # Log every 10 attempts (20 seconds)
                print(f"tk -- Status: {status}, waiting... (attempt {attempt}/{max_attempts})")
            time.sleep(2)  # Wait 2 seconds before next poll
        
        # If we've exhausted all attempts
        raise Exception(f"Transcription timed out after {max_attempts * 2} seconds")
            
    except requests.exceptions.Timeout:
        print(f"tk -- Request timeout")
        raise Exception("transcription_error: Request timed out")
    except Exception as e:
        error_msg = str(e)
        print(f"tk -- Transcription error: {error_msg}")
        
        # Check if it's already a formatted error
        if "transcription_error:" in error_msg:
            raise Exception(error_msg)
        else:
            raise Exception(f"transcription_error: {error_msg}")
